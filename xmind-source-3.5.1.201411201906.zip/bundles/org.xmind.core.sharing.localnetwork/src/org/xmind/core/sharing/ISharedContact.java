package org.xmind.core.sharing;

/**
 * @author Jason Wong
 */
public interface ISharedContact {

    String getID();

    String getName();

}
