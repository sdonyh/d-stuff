package org.xmind.core.io.workbook;

public interface WorkbookConstants {

    String FILE_EXTENSION = ".xmind"; //$NON-NLS-1$

}
